namespace L8
{
    public interface ICalculator<X, Y>
    {
        X Addition(X a, Y b);
        X Subtraction(X a, Y b);
        X Multiply(X a, Y b);
        X Divide(X a, Y b);
        X Power(X a, int degree);
        double SquareRoot(X a);
    }
}