﻿
namespace L8
{   
    class Program
    {
        static void Main()
        {
            Calculator calc = new Calculator();
            
            Console.WriteLine("Addition: " + calc.Addition(5, 3));
            Console.WriteLine("Subtraction: " + calc.Subtraction(10, 4));
            Console.WriteLine("Multiple: " + calc.Multiply(6, 7));
            Console.WriteLine("Divide: " + calc.Divide(20, 5));
            Console.WriteLine("Pow: " + calc.Power(2, 3));
            Console.WriteLine("Square: " + calc.SquareRoot(25));
        }
    }
}

