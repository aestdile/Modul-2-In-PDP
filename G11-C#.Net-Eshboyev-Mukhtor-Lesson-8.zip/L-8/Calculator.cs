
namespace L8
{
    public class Calculator : ICalculator<double, double>
    {
        public double Addition(double a, double b) => a + b;
        public double Subtraction(double a, double b) => a - b;
        public double Multiply(double a, double b) => a * b;
        public double Divide(double a, double b) => b != 0 ? a / b : throw new DivideByZeroException("Not Divide!");
        public double Power(double a, int degree) => Math.Pow(a, degree);
        public double SquareRoot(double a) => a >= 0 ? Math.Sqrt(a) : throw new ArgumentException("a should not be negative number!");
    }
}