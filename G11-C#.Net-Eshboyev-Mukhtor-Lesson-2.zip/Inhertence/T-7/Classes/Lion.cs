
namespace T7
{
    class Lion : ZooAnimal
    {
        public Lion() : base("Lion") { }

        public void Roar()
        {
            Console.WriteLine("Lion: ROARRR!");
        }
    }
}