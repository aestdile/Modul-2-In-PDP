
namespace T1
{
    class Car : Vehicle
    {
        public int NumberOfDoors { get; set; }

        public Car(string brand, string model, int numberOfDoors)
            : base(brand, model)
        {
            NumberOfDoors = numberOfDoors;
        }

        public new void DisplayInfo()
        {
            base.DisplayInfo();
            Console.WriteLine($"Number of Doors: {NumberOfDoors}");
        }
    }
}







