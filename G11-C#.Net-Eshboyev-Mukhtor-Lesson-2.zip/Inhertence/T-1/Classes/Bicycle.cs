
namespace T1
{
    class Bicycle : Vehicle
    {
        public bool HasBasket { get; set; }

        public Bicycle(string brand, string model, bool hasBasket)
            : base(brand, model)
        {
            HasBasket = hasBasket;
        }

        public new void DisplayInfo()
        {
            base.DisplayInfo();
            Console.WriteLine($"Has Basket: {HasBasket}");
        }
    }
}

