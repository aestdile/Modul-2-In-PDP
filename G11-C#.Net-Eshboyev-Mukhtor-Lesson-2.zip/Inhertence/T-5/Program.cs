﻿
namespace T5
{
    class Program
    {
        static void Main()
        {
            Warrior warrior = new Warrior("Thor", 100);
            warrior.DisplayInfo();
            warrior.Attack();

            Console.WriteLine();

            Mage mage = new Mage("Gandalf", 80);
            mage.DisplayInfo();
            mage.CastSpell();
        }
    }
}








