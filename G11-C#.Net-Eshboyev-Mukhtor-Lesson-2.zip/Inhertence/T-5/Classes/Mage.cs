
namespace T5
{
    class Mage : Character
    {
        public Mage(string name, int health)
            : base(name, health)
        {
        }

        public void CastSpell()
        {
            Console.WriteLine($"{Name} casts a powerful spell!");
        }
    }
}
