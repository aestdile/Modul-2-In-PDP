

namespace T5
{
    class Character
    {
        public string Name { get; set; }
        public int Health { get; set; }

        public Character(string name, int health)
        {
            Name = name;
            Health = health;
        }

        public void DisplayInfo()
        {
            Console.WriteLine($"Character: {Name}, Health: {Health}");
        }
    }
}