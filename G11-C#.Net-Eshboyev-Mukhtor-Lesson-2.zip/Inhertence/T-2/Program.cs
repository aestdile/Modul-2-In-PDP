﻿
namespace T2
{
    class Program
    {
        static void Main()
        {
            Manager manager = new Manager("Alice", 35, 5000);
            manager.DisplayInfo();
            
            Console.WriteLine();

            Developer developer = new Developer("Bob", 28, "C#");
            developer.DisplayInfo();
        }
    }
}










