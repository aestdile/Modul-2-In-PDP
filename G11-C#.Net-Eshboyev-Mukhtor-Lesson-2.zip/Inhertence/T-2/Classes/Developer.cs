
namespace T2
{
    class Developer : Employee
    {
        public string ProgrammingLanguage { get; set; }

        public Developer(string name, int age, string programmingLanguage)
            : base(name, age)
        {
            ProgrammingLanguage = programmingLanguage;
        }

        public new void DisplayInfo()
        {
            base.DisplayInfo();
            Console.WriteLine($"Programming Language: {ProgrammingLanguage}");
        }
    }
}


