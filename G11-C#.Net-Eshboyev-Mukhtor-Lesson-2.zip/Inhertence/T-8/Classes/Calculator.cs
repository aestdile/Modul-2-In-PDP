
namespace Calculator
{ 
    abstract class AbstractCalculator
    {
        public abstract double Calculate(double a, double b);
    }

    class Addition : AbstractCalculator
    {
        public override double Calculate(double a, double b) => a + b;
    }

    class Subtraction : AbstractCalculator
    {
        public override double Calculate(double a, double b) => a - b;
    }

    class Multiplication : AbstractCalculator
    {
        public override double Calculate(double a, double b) => a * b;
    }

    class Division : AbstractCalculator
    {
        public override double Calculate(double a, double b)
        {
            return a / b;
        }
    }

    class Power : AbstractCalculator
    {
        public override double Calculate(double a, double b) => Math.Pow(a, b);
    }

    class SquareRoot : AbstractCalculator
    {
        public override double Calculate(double a, double b) 
        {
            return Math.Sqrt(a);
        }
    }
}
