
namespace T8
{
    class Phone: ElectronicDevices
    {
        public Phone(string brand) : base (brand){}

        public void MakeCall()
        {
            Console.WriteLine($"{Brand} Phone: Making a call... ");
        }
    }
}