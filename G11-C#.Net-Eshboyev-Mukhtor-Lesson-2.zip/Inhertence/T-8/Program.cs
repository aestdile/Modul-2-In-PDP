﻿/*
namespace T8
{
    class Program
    {
        static void Main()
        {
            
            Phone myPhone=new Phone("Iphone 17 Pro Max");
            myPhone.DisplayInfo();
            myPhone.MakeCall();

            Console.WriteLine();

            Laptop myLaptop=new Laptop("Mac M3 Pro");
            myLaptop.DisplayInfo();
            myLaptop.CompileCode();
            
        }     
    }
}
*/

namespace Calculator
{   
    class Program
    {
        static void Main()
        {
            Console.WriteLine("Enter nums: ");
            Console.Write("num1: ");
            double num1 = Convert.ToDouble(Console.ReadLine());

            Console.Write("num2: ");
            double num2 = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Choose option (+, -, *, /, ^, sqrt): ");
            string operation = Console.ReadLine();

            AbstractCalculator calculator;

            switch (operation)
            {
                case "+":
                    calculator = new Addition();
                    break;
                case "-":
                    calculator = new Subtraction();
                    break;
                case "*":
                    calculator = new Multiplication();
                    break;
                case "/":
                    calculator = new Division();
                    break;
                case "^":
                    calculator = new Power();
                    break;
                case "sqrt":
                    calculator = new SquareRoot();
                    num2 = 0; 
                    break;
                default:
                    Console.WriteLine("Incorrect option!");
                    return;
            }
            double result = calculator.Calculate(num1, num2);
            Console.WriteLine($"Result: {result}");
        }
    }
}