﻿
namespace T3
{
    class Program
    {
        static void Main()
        {
            Student student = new Student("Alice", 20, 3.8);
            student.DisplayInfo();
            
            Console.WriteLine();

            Teacher teacher = new Teacher("Mr. Smith", 45, "Mathematics");
            teacher.DisplayInfo();
        }
    }
}














