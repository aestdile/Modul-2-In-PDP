using Newtonsoft.Json;

namespace L9
{
    public class Changes
    {
        private string filePath = "developers.json";

        public void AllChanges()
        {
            if (!File.Exists(filePath))
            {
                Console.WriteLine("Not found data!");
                return;
            }

            string jsonData = File.ReadAllText(filePath);
            List<Developers> developers = JsonConvert.DeserializeObject<List<Developers>>(jsonData);

            Console.WriteLine("\n New Updated Data:");
            Console.WriteLine("------------------------------------------------------");

            foreach (var developer in developers)
            {
                Console.WriteLine($"ID: {developer.ID}");
                Console.WriteLine($"Name: {developer.Name}");
                Console.WriteLine($"Position: {developer.Position}");
                Console.WriteLine($"Hobby: {developer.Hobby}");
                Console.WriteLine($"Salary: {developer.Salary}");
                Console.WriteLine($"Company: {developer.Company}");
                Console.WriteLine("------------------------------------------------------");
            }
        }
    }
}
