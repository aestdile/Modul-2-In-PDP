﻿
namespace L9
{
    class Program
    {
        static void Main()
        {
            Developers developers=new Developers();
            AllDeveloprs allDeveloprs=new AllDeveloprs();
            UpdateDevelopers updateDevelopers=new UpdateDevelopers();
            DeleteDevelopers deleteDevelopers=new DeleteDevelopers();
            Changes changes=new Changes();

            while (true)
            {
                Console.WriteLine("\n1. Add Developers"); // Done!
                Console.WriteLine("\n2. See All Developrs"); // Done!
                Console.WriteLine("\n3. Update Developers' Informations"); // Done!
                Console.WriteLine("\n4. Delete Developers"); // Done!
                Console.WriteLine("\n5. Last Changes"); // Done!
                Console.WriteLine("\n6. Sign Out"); // Done!
                Console.WriteLine();
                Console.Write("Choise: ");
                string choise=Console.ReadLine();
                Console.WriteLine();
                switch(choise)
                {
                    case "1":
                        developers.AddDevelopers();
                        break;
                    case "2":
                        allDeveloprs.SeeAllDevelopers();
                        break;
                    case "3":
                        updateDevelopers.UpdateDevelopersProperties();
                        break;
                    case "4":
                        deleteDevelopers.DeleteDeveloper();
                        break;
                    case "5":
                        changes.AllChanges();
                        break;
                    case "6":
                        Console.WriteLine("Program is finished!");
                        return;
                    default:
                        Console.WriteLine("Incorrect choise!");
                        break;
                }
            }
        }
    }
}