

namespace T4
{
    class BankAccount
    {
        public string AccountNumber { get; set; }
        public double Balance { get; set; }

        public BankAccount(string accountNumber, double balance)
        {
            AccountNumber = accountNumber;
            Balance = balance;
        }

        public void DisplayInfo()
        {
            Console.WriteLine($"Account Number: {AccountNumber}, Balance: ${Balance}");
        }
    }
}