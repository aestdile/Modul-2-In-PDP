

namespace T4
{
    class CheckingAccount : BankAccount
    {
        public double OverdraftLimit { get; set; }

        public CheckingAccount(string accountNumber, double balance, double overdraftLimit)
            : base(accountNumber, balance)
        {
            OverdraftLimit = overdraftLimit;
        }

        public new void DisplayInfo()
        {
            base.DisplayInfo();
            Console.WriteLine($"Overdraft Limit: ${OverdraftLimit}");
        }
    }
}