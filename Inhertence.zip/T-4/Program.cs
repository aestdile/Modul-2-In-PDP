﻿
namespace T4
{
    class Program
    {
        static void Main()
        {
            SavingsAccount savings = new SavingsAccount("SA12345", 5000, 2.5);
            savings.DisplayInfo();
            
            Console.WriteLine();

            CheckingAccount checking = new CheckingAccount("CA67890", 1500, 1000);
            checking.DisplayInfo();
        }
    }
}









