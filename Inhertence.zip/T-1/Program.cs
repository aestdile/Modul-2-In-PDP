﻿
namespace T1
{
    class Program
    {
        static void Main()
        {
            Car car = new Car("Toyota", "Corolla", 4);
            car.DisplayInfo();
            
            Console.WriteLine();

            Bicycle bicycle = new Bicycle("Giant", "Escape 3", true);
            bicycle.DisplayInfo();
        }
    }
}














