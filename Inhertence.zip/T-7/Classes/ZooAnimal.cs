

namespace T7
{
    class ZooAnimal
    {
        public string Name { get; set; }

        public ZooAnimal(string name)
        {
            Name = name;
        }

        public void DisplayInfo()
        {
            Console.WriteLine($"Animal: {Name}");
        }
    }
}