

namespace T7
{
    class Elephant : ZooAnimal
    {
        public Elephant() : base("Elephant") { }

        public void SprayWater()
        {
            Console.WriteLine("Elephant: Spraying water!");
        }
    }
}