﻿
namespace T7
{
    class Program
    {
        static void Main()
        {
            Lion lion = new Lion();
            lion.DisplayInfo();
            lion.Roar();

            Console.WriteLine();

            Elephant elephant = new Elephant();
            elephant.DisplayInfo();
            elephant.SprayWater();
        }
    }
}


