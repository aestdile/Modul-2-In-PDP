
namespace T2
{
    class Manager : Employee
    {
        public double Bonus { get; set; }

        public Manager(string name, int age, double bonus)
            : base(name, age)
        {
            Bonus = bonus;
        }

        public new void DisplayInfo()
        {
            base.DisplayInfo();
            Console.WriteLine($"Bonus: ${Bonus}");
        }
    }
}