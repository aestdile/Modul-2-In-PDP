﻿
namespace T6
{
    class Program
    {
        static void Main()
        {
            Guitar guitar = new Guitar();
            guitar.DisplayInfo();
            guitar.PlaySound();

            Console.WriteLine();

            Piano piano = new Piano();
            piano.DisplayInfo();
            piano.PlaySound();
        }
    }
}







