
namespace T6
{  
    class Guitar : Instrument
    {
        public Guitar() : base("Guitar") { }

        public override void PlaySound()
        {
            Console.WriteLine("Strumming guitar strings... ");
        }
    }
}