
namespace T6
{  
    class Piano : Instrument
    {
        public Piano() : base("Piano") { }

        public override void PlaySound()
        {
            Console.WriteLine("Playing piano keys... ");
        }
    }
}
