
namespace T6
{
    abstract class Instrument
    {
        public string Name { get; set; }

        public Instrument(string name)
        {
            Name = name;
        }

        public abstract void PlaySound();

        public void DisplayInfo()
        {
            Console.WriteLine($"Instrument: {Name}");
        }
    }
}