
namespace T8
{
    class ElectronicDevices
    {
        public string Brand{get; set;}


        public ElectronicDevices(string brand)
        {
            Brand=brand;
        }

        public void DisplayInfo()
        {
            Console.WriteLine($"Electronic device: {Brand}");
        }
    }
}