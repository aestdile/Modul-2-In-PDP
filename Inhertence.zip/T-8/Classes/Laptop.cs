
namespace T8
{
    class Laptop: ElectronicDevices
    {
        public Laptop(string brand) : base (brand){}

        public void CompileCode()
        {
            Console.WriteLine($"{Brand} Laptop: Compiling code... ");
        }
    }
}








