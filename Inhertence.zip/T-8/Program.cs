﻿
namespace T8
{
    class Program
    {
        static void Main()
        {
            Phone myPhone=new Phone("Iphone 17 Pro Max");
            myPhone.DisplayInfo();
            myPhone.MakeCall();

            Console.WriteLine();

            Laptop myLaptop=new Laptop("Mac M3 Pro");
            myLaptop.DisplayInfo();
            myLaptop.CompileCode();
        }
    }
}








