
namespace T5
{
    class Warrior : Character
    {
        public Warrior(string name, int health)
            : base(name, health)
        {
        }

        public void Attack()
        {
            Console.WriteLine($"{Name} attacks with a sword!");
        }
    }
}
