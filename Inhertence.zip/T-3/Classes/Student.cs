namespace T3
{     
    class Student : Person
    {
        public double GPA { get; set; }

        public Student(string name, int age, double gpa)
            : base(name, age)
        {
            GPA = gpa;
        }

        public new void DisplayInfo()
        {
            base.DisplayInfo();
            Console.WriteLine($"GPA: {GPA}");
        }
    }
}