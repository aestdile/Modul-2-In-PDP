﻿
namespace L7
{
    class Program
    {
        static void Main()
        {
            /*
            // T-1
            var data=new DayOfTheWeek();
            Console.WriteLine($"Today is {data.ReturnDayOfTheWeek()}");
            

            // T-2
            var weather=new TheWeatherCondition();
            Console.WriteLine($"Weather is {weather.ReturnWeatherCondition()}");
            
            // T-3
            var traffic=new TheTrafficLight();
            Console.WriteLine(traffic.ReturnTrafficLight(TrafficLight.Green));
            

            // T-4
            ManagerOfTheGame manager=new ManagerOfTheGame();
            manager.ShowMenuOptions();
            

            // T-5
            PayOfMethods pay=new PayOfMethods();
            pay.EnumToString();
            
            // T-6
            StringToEnum data=new StringToEnum();
            data.FromStringToEnum();
            

            // T-7
            Months months=new Months();
            months.GetMonthName();
            

            // T-12
            CountSalary money=new CountSalary();
            money.SumSalary();
            
            
            // T-13
            SportPlayers sport=new SportPlayers();
            sport.GetPlayerCount();

            
            // T-14
            CarPrice carPrice=new CarPrice();
            carPrice.GetCarPrice();
            */
            // Ko'plab masalar o'xshash va deyarli takrorlangan.
        }
    }
}
















