
namespace L7
{
    public enum WeatherCondition
    {
        Sunny = 1,
        Rainy = 2,
        Cloudy = 3,
        Snowy = 4,
    }

    public class TheWeatherCondition
    {
        public string ReturnWeatherCondition()
        {
            Console.Write("Enter num: ");
            int num;
            if (!int.TryParse(Console.ReadLine(), out num))
            {
                return "Invalid input, please, come again num: ";
            }
            if (Enum.IsDefined(typeof(WeatherCondition), num))
            {
                return ((WeatherCondition)num).ToString();
            }
            return "Incorrect num!";
        }
    }
}