
namespace L7
{
    public enum TrafficLight
    {
        Red,
        Yellow,
        Green
    }

    public class TheTrafficLight
    {
        public string ReturnTrafficLight(TrafficLight data)
        {
            switch (data)
            {
                case TrafficLight.Red:
                    return "Stop!";
                case TrafficLight.Yellow:
                    return "Please, Wait!";
                case TrafficLight.Green:
                    return "Go!";
                default:
                    return "Invalid Error!";
            }
        }
    }
}