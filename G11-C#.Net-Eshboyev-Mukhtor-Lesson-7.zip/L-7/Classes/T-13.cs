namespace L7
{
    public enum SportType
    {
        Football, Basketball, Tennis
    }

    public class SportPlayers
    {
        public void GetPlayerCount()
        {
            Console.Write("Choise type of Sport (Football, Basketball, Tennis): ");
            string input = Console.ReadLine();

            if (Enum.TryParse(input, out SportType sport) &&
                Enum.IsDefined(typeof(SportType), sport))
            {
                int players = sport switch
                {
                    SportType.Football => 11,
                    SportType.Basketball => 5,
                    SportType.Tennis => 1,
                    _ => 0
                };
                Console.WriteLine($"Count of player in this sport: {players}");
            }
            else
            {
                Console.WriteLine("Entered incorrect type of sport!");
            }
        }
    }
}
