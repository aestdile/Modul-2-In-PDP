namespace L7
{
    public enum DayOfWeek
    {
        Monday, 
        Tuesday, 
        Wednesday,
        Thursday,
        Friday,
        Saturday,
        Sunday
    }

    public class DayOfTheWeek
    {
        public string ReturnDayOfTheWeek()
        {
            DayOfWeek data = DayOfWeek.Monday;
            return data.ToString();
        }
    }
}