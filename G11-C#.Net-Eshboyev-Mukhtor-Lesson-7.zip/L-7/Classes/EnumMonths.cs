
namespace L7
{
    public enum Month
    {
        January = 1, 
        February, 
        March, 
        April, 
        May, 
        June,
        July, 
        August, 
        September, 
        October, 
        November, 
        December
    }

    public class Months
    {
        public void GetMonthName()
        {
            Console.Write("Enter number of Months (1-12): ");
            if (int.TryParse(Console.ReadLine(), out int monthNumber) &&
                Enum.IsDefined(typeof(Month), monthNumber))
            {
                Console.WriteLine($"Name of Month: {(Month)monthNumber}");
            }
            else
            {
                Console.WriteLine("Incorrect number!");
            }
        }
    }
}
