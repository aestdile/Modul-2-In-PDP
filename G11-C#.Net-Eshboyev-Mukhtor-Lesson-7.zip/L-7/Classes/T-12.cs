namespace L7
{
    public enum JobPosition
    {
        Intern, Junior, Mid, Senior, Lead
    }

    public class CountSalary
    {
        public void SumSalary()
        {
            Console.Write("Choise position: (Intern, Junior, Mid, Senior, Lead): ");
            string input = Console.ReadLine();

            if (Enum.TryParse(input, out JobPosition position) &&
                Enum.IsDefined(typeof(JobPosition), position))
            {
                int salary = position switch
                {
                    JobPosition.Intern => 500,
                    JobPosition.Junior => 1500, //Amiyn
                    JobPosition.Mid => 3000,
                    JobPosition.Senior => 5000,
                    JobPosition.Lead => 7000,
                    _ => 0
                };
                Console.WriteLine($"Your salary: ${salary}");
            }
            else
            {
                Console.WriteLine("Entered incorrect position!");
            }
        }
    }
}
