
namespace L7
{
    public enum PaymentMethod
    {
        Cash,
        CreditCard,
        PayPal
    }

    public class PayOfMethods
    {
        public void EnumToString()
        {
            foreach (var data in Enum.GetValues(typeof(PaymentMethod)))
            {
                Console.WriteLine(data.ToString());
            }            
        }
    }
}