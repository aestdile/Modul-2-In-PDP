

// The same with sixth problem

