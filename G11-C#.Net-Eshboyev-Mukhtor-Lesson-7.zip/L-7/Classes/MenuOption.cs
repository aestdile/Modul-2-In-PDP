
namespace L7
{
    public enum MenuOptions
    {
        Start=1,
        Settings=2, 
        Exit=3
    }

    class ManagerOfTheGame
    {
        public void ShowMenuOptions()
        {
            bool isRunning = true;

            while (isRunning)
            {
                Console.Clear();
                Console.WriteLine("---- MenuOptions ----");
                Console.WriteLine("1. Start");
                Console.WriteLine("2. Settings");
                Console.WriteLine("3. Exit");
                Console.Write("Tanlovingizni kiriting: ");

                if (int.TryParse(Console.ReadLine(), out int choice) && Enum.IsDefined(typeof(MenuOptions), choice))
                {
                    MenuOptions selectedOption = (MenuOptions)choice;
                    switch (selectedOption)
                    {
                        case MenuOptions.Start:
                            Console.WriteLine("The Game started, go go ...");
                            break;

                        case MenuOptions.Settings:
                            Console.WriteLine("Opened windows of The Game ...");
                            break;

                        case MenuOptions.Exit:
                            Console.WriteLine("Exit from The Game ...");
                            isRunning = false;
                            break;
                    }
                }
                else
                {
                    Console.WriteLine("Incorrect choice! Please, Enter again.");
                }
                Console.WriteLine("\nTouch a button to continue the game ...");
                Console.ReadKey();
            }
        }
    }
}