namespace L7
{
    public enum CarType
    {
        Sedan, SUV, Coupe
    }

    public class CarPrice
    {
        public void GetCarPrice()
        {
            Console.Write("Choise option (Sedan, SUV, Coupe): ");
            string input = Console.ReadLine();

            if (Enum.TryParse(input, out CarType car) &&
                Enum.IsDefined(typeof(CarType), car))
            {
                int price = car switch
                {
                    CarType.Sedan => 20000,
                    CarType.SUV => 35000,
                    CarType.Coupe => 45000,
                    _ => 0
                };
                Console.WriteLine($"Price : ${price}");
            }
            else
            {
                Console.WriteLine("Incorrect value!");
            }
        }
    }
}
