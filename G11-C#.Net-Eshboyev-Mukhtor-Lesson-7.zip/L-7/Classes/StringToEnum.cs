

namespace L7
{
    public enum PaymentEnum  // Enum nomini to'g'riladik
    {
        Cash,
        CreditCard,
        DebitCard,
        PayPal
    }

    public class StringToEnum
    {
        public void FromStringToEnum()
        {
            Console.Write("Enter Pay method: (Cash, CreditCard, DebitCard, PayPal): ");
            string data = Console.ReadLine();

            if (Enum.TryParse(data, true, out PaymentEnum PaymentEnum) && Enum.IsDefined(typeof(PaymentEnum), PaymentEnum))
            {
                Console.WriteLine($"Method that You have chosen: {PaymentEnum}");
            }
            else
            {
                Console.WriteLine("Entered incorrect pay method");
            }
        }
    }
}
