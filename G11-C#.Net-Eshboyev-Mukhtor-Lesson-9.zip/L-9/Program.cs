﻿
namespace L9
{
    class Program
    {
        static void Main()
        {
            Console.Write("Enter a number: ");
            if (int.TryParse(Console.ReadLine(), out int number))
            {
                NumberConverter converter = new NumberConverter();
                string words = converter.NumberToWords(number);
                Console.WriteLine("Number in words: " + words);
            }
            else
            {
                Console.WriteLine("Invalid input. Please enter a valid integer.");
            }
        }
    }
}




