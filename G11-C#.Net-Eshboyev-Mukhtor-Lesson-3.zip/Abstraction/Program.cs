﻿
namespace Abstraction.Classes
{
    class Program
    {
        static void Main()
        {
            /*
            Protcess protcess = new Protcess();
            Console.WriteLine($"CardType: {protcess.CardType()}");
            Console.WriteLine($"Code: {protcess.Code()}");
            Console.WriteLine($"Available Sum: {protcess.Sum()}");
            */

            /*

            Malibu malibu = new Malibu();
            Console.WriteLine($"Gass: {malibu.Gass()}");
            Console.WriteLine($"Brake: {malibu.Brake()}");
            Console.WriteLine($"Light: {malibu.Light()}");
            Console.WriteLine($"Speed: {malibu.Speed()}");
            Console.WriteLine($"WasteFluent: {malibu.WasteFluent()}");
            Console.WriteLine($"Conditsioner: {malibu.Conditsioner()}");

            Console.WriteLine();

            Gentra gentra = new Gentra();
            Console.WriteLine($"Gass: {gentra.Gass()}");
            Console.WriteLine($"Brake: {gentra.Brake()}");
            Console.WriteLine($"Light: {gentra.Light()}");
            Console.WriteLine($"Speed: {gentra.Speed()}");
            Console.WriteLine($"WasteFluent: {gentra.WasteFluent()}");
            Console.WriteLine($"Conditsioner: {gentra.Conditsioner()}");

            Console.WriteLine();

            BMW bmw = new BMW();
            Console.WriteLine($"Gass: {bmw.Gass()}");
            Console.WriteLine($"Brake: {bmw.Brake()}");
            Console.WriteLine($"Light: {bmw.Light()}");
            Console.WriteLine($"Speed: {bmw.Speed()}");
            Console.WriteLine($"WasteFluent: {bmw.WasteFluent()}");
            Console.WriteLine($"Conditsioner: {bmw.Conditsioner()}");
            Console.WriteLine();
            */

            /*
            Console.WriteLine();

            CountPart countPart = new CountPart();
            Console.WriteLine($"Add: {countPart.Add(7, 8)}");
            Console.WriteLine($"Subtract: {countPart.Subtract(9, 2)}");
            Console.WriteLine($"Multiply: {countPart.Multiply(5, 4)}");
            Console.WriteLine($"Divide: {countPart.Divide(4, 2)}");
            Console.WriteLine($"Modulus: {countPart.Modulus(-7, -6)}");
            Console.WriteLine($"SquareRoot: {countPart.SquareRoot(169)}");
            Console.WriteLine($"Power: {countPart.Power(5, 5)}");
            Console.WriteLine();
            */

            string num1="123", num2="456";
            int res=int.Parse(num1)*int.Parse(num2);
            Console.WriteLine($"num1 * num2 = {res}");
        }
    }
}








