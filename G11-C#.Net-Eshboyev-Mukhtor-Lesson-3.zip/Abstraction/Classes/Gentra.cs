﻿
namespace Abstraction.Classes
{
    public class Gentra : Avtomobil
    {
        public Gentra()
        {
            Gass();
            Brake();
            Light();
            Speed();
            WasteFluent();
            Conditsioner();
        }
        public override string Gass() => "Turn On the Gentra.";
        public override string Brake() => "Gentra is stopped.";
        public override string Light() => "Ultra Light";
        public override string Speed() => "Speed 200 km/h";
        public override string WasteFluent() => $"Gentra waste fuel 10 litr according to 100 km.";
        public override bool Conditsioner() => true;
    }
}
