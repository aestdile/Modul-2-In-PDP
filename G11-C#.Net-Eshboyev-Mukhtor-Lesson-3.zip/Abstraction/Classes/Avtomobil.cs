﻿

namespace Abstraction.Classes
{
    public abstract class Avtomobil
    {
        public abstract string Gass();
        public abstract string Brake();
        public abstract string Light();
        public abstract string Speed();
        public abstract string WasteFluent();
        public abstract bool Conditsioner();
    }
}
