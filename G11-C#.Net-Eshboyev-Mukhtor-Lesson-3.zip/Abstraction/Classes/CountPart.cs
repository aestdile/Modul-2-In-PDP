﻿

namespace Abstraction.Classes
{
    public class CountPart : Calculator
    {
        public override double Add(double a, double b) => a + b;
        public override double Subtract(double a, double b) => a - b;
        public override double Multiply(double a, double b) => a * b;
        public override double Divide(double a, double b) => a / b;
        public override double Modulus(double a, double b) => a % b;
        public override double SquareRoot(double a) => Math.Sqrt(a);
        public override double Power(double a, double b) => Math.Pow(a, b);
    }
}
