namespace Abstraction
{
    public class Protcess : Bankomat
    {
        public Protcess()
        {
            CardType();
            Code();
            Sum();
        }

        public override string CardType()
        {
            return "Visa";
        }

        public override string Code()
        {
            return "1234";
        }

        public override double Sum()
        {
            return 1000;
        }



    }
}