﻿

namespace Abstraction.Classes
{
    public abstract class Calculator
    {
        public abstract double Add(double a, double b);
        public abstract double Subtract(double a, double b);
        public abstract double Multiply(double a, double b);
        public abstract double Divide(double a, double b);
        public abstract double Modulus(double a, double b);
        public abstract double SquareRoot(double a);
        public abstract double Power(double a, double b);
    }
}
