
namespace Abstraction
{
    public abstract class Bankomat
    {
        public abstract string CardType();
        public  abstract string Code();
        public abstract double Sum();
    }
}














