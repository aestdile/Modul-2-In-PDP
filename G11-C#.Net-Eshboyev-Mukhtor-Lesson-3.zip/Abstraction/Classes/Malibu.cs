﻿
namespace Abstraction.Classes
{
    public class Malibu : Avtomobil
    {
        public Malibu()
        {
            Gass();
            Brake();
            Light();
            Speed();
            WasteFluent();
            Conditsioner();
        }
        public override string Gass() => "Turn On the Malibu.";
        public override string Brake() => "Malibu is stopped.";
        public override string Light() => "Ultra Light";
        public override string Speed() => "Speed 220 km/h";
        public override string WasteFluent() =>  $"Malibu waste fuel 15 litr according to 100 km.";
        public override bool Conditsioner() => true;
    }
}
