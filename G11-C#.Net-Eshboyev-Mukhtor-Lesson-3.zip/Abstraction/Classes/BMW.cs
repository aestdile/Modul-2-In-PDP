﻿
namespace Abstraction.Classes
{
    public class BMW : Avtomobil
    {
        public BMW()
        {
            Gass();
            Brake();
            Light();
            Speed();
            WasteFluent();
            Conditsioner();
        }
        public override string Gass() => "Turn On the BMW.";
        public override string Brake() => "BMW is stopped.";
        public override string Light() => "Ultra Light";
        public override string Speed() => "Speed 250 km/h";
        public override string WasteFluent() => $"BMW waste fuel 20 litr according to 100 km.";
        public override bool Conditsioner() => true;
    }
}
